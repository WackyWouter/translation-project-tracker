# CHANGELOG


## V 3.0.0
- Bootstrap 5 updation

## V 2.1.0

- Updated RTL layout wih arabic translation

## V 2.0.0

- Introduced modern dashboard
- Introduced horizontal layouts
- Updated template dependency packages
- Bug fixes

## V 1.5.0

- Some design improvements and bug fixes
- Updated template dependency packages
- Removed Bower package manager support
  (Now we use node package manager instead of Bower)
- Added vendors bundle to remove 'node_modules' folder dependency
  (Now 'npm install' command is not needed for preview purpose)
- Some responsive fixes
- Fixed some plugins no working properly

## V 1.2.0

- Some design improvements and bug fixes

## V 1.1.0

- Bug fix : Added missing vendor files

## V 1.0.0

- Initial release
